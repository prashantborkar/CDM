# CDM: Run This on Your Machine

This makes your laptop do a real certificate deployment (into your own Windows certificate store),
and report the result into the same shared ServiceNow instance the rest of the team is using. Your
machine already shows up there as `Local_Laptop_POC_MID_Gaurav`, validated and Up — this uses that
same connection.

You don't need to coordinate with anyone else to run this, and running it doesn't touch or interfere
with anyone else's data — everything you do here is tagged `gaurav-win` / `gaurav-lnx`, separate from
`lab-win` / `lab-lnx`.

## One-time setup

1. Make sure Python is installed (`python --version` in a terminal; if missing, install from
   python.org).
2. Unzip this package somewhere, e.g. `C:\CDM\implementation`.
3. Open a terminal in that folder and install one dependency:
   ```
   python -m pip install cryptography
   ```
4. Store your ServiceNow admin credential locally (only on your machine — this is not saved
   anywhere else, and doesn't get sent back to anyone):
   ```
   python -c "from vault_stub.vault import set_credential; set_credential('servicenow/admin', 'admin', 'Password@2026')"
   ```
   (If the admin password has changed since you got this, use the current one.)

## Run the demo

Open **three terminals** in the `implementation` folder:

```
# once, to create your starting certificates
python seed.py

# terminal 1 -- keep running
python lab_site/server.py

# terminal 2 -- keep running
python ca_simulator/server.py

# terminal 3 -- runs the full loop once
python orchestrator/run.py demo
```

That deploys a real certificate into your Windows certificate store, verifies it live, and confirms
it — all on your machine, independent of anyone else.

## Push the result into the shared ServiceNow instance

```
python servicenow/sync_cmdb_to_sn.py
```

Then check in ServiceNow: **All > u_x_2182912_certif_0_certificate** (or ask whoever set it up for
the list view link). You should see two new rows — `gaurav-win:web01.gaurav.example.com` and
`gaurav-lnx:api.gaurav.example.com` — sitting alongside the `lab-win` / `lab-lnx` ones already there,
both showing `State = Confirmed by discovery` with real thumbprints and timestamps.

## Optional: let ServiceNow trigger it

Instead of running `orchestrator/run.py demo` yourself, you can have ServiceNow request the
deployment and your machine react to it:

1. Run `sync` and `plan` first so there's something to deploy:
   ```
   python orchestrator/run.py sync
   python orchestrator/run.py plan
   ```
2. In ServiceNow, open the `gaurav-win:...` record and set its **State** field to
   `Deploy Requested`.
3. On your machine, run:
   ```
   python servicenow/poll_and_deploy.py --once
   ```
   It'll see the request, run the real deployment, and write the result back — the same pattern
   already proven on the other machine.

## Please don't run

`servicenow/setup_certificate_table.py` doesn't exist in this copy on purpose — it would delete and
recreate the *shared* table, wiping out everyone else's data. If you ever see a script like that,
don't run it against the shared instance.

## Questions / something doesn't work

Screenshot the error and send it back — same as how the rest of this got built.
